import speech_recognition as sr
import pyttsx3
r = sr.Recognizer() 

with sr.Microphone() as source1:
    print("Welcome to speech to text convertor")
    print("Silence Please!")
    
    r.adjust_for_ambient_noise(source1, duration=2)
    print("Please speak now")
    audio1 = r.listen(source1)
    Text = r.recognize_google(audio1)

    print("You Said: " + Text)