import customtkinter as ctk
def login_historyf():
    with open("login_history.txt", "r") as file:
        return file.readlines()

def admin_guif():
    login_details = login_historyf()

    root = ctk.CTk()
    root.title("Admin")
    root.geometry("600x400")

    label_welcome = ctk.CTkLabel(root, text="Admin Page : Manya Chudasama", font=("Helvetica Neue", 20, "bold"))
    label_welcome.pack(pady=20)

    label_history = ctk.CTkLabel(root, text="Login History (User and Admin both)", font=("Helvetica Neue", 16))
    label_history.pack(pady=10)

    history_text = ctk.CTkTextbox(root, font=("Helvetica Neue", 14), width=500, height=200)
    history_text.pack(pady=10)

    for login in login_details:
        history_text.insert("end", login)

    user_logins = sum(1 for login in login_details if "User" in login)
    admin_logins = sum(1 for login in login_details if "Admin" in login)

    label_user_count = ctk.CTkLabel(root, text=f"Total User Logins: {user_logins}", font=("Helvetica Neue", 14))
    label_user_count.pack(pady=5)

    label_admin_count = ctk.CTkLabel(root, text=f"Total Admin Logins: {admin_logins}", font=("Helvetica Neue", 14))
    label_admin_count.pack(pady=5)

    root.mainloop()

admin_guif()