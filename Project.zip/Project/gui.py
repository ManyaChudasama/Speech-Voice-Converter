import tkinter as tk
import subprocess
 
root = tk.Tk()
root.title("Run Python Scripts GUI")
root.geometry("1689x950")

bg = tk.PhotoImage(file="img.png")
bg_frame = tk.Label(root, image=bg)
bg_frame.place(x=0, y=0, relwidth=1, relheight=1)  

frame = tk.Frame(root, bg="#FFFFFF")  
frame.place(relx=0.5, rely=0.5, anchor='center')  

tk.Label(frame, background="white", text="Welcome to Speech-Text Converter", fg='#052A47', font=("Arial", 30, "bold"), padx=30, pady=30).grid(row=0, column=0, columnspan=2)

button_width = 25
tk.Button(frame, text="Speech to Text", width=button_width, highlightbackground='#A3D376', highlightthickness=2, background='#A3D376',
          command=lambda: subprocess.Popen(['start', 'cmd', '/k', 'python Project_Part_1.py'], shell=True),
          font=("Calibri", 25),padx=15, pady=15).grid(row=1, column=0, padx=30, pady=15)

tk.Button(frame, text="Entered Text to Speech", width=button_width, highlightbackground='#A3D376', highlightthickness=2, background='#A3D376',
          command=lambda: subprocess.Popen(['start', 'cmd', '/k', 'python Project_Part_2.py'], shell=True),
          font=("Calibri", 25), padx=15, pady=15).grid(row=1, column=1, padx=30, pady=15)

tk.Button(frame, text="Text File to Speech", width=button_width, highlightbackground='#A3D376', highlightthickness=2, background='#A3D376',
          command=lambda: subprocess.Popen(['start', 'cmd', '/k', 'python Project_part3.py'], shell=True),
          font=("Calibri", 25), padx=15, pady=15).grid(row=2, column=0, padx=30, pady=15)

tk.Button(frame, text="PDF File to Speech", width=button_width, highlightbackground='#A3D376', highlightthickness=2, background='#A3D376',
          command=lambda: subprocess.Popen(['start', 'cmd', '/k', 'python Project_part4.py'], shell=True),
          font=("Calibri", 25), padx=15, pady=15).grid(row=2, column=1, padx=30, pady=15)
tk.Button(frame, text="Close", width=10, height=1, highlightbackground='#A3D376', highlightthickness=2, background='#A3D376',
          command=root.destroy,font=("Calibri", 25), padx=10, pady=10).grid(row=3, column=0,columnspan=2, padx=20, pady=15)

name_label1 = tk.Label(root, text="Group 3", fg='#052A47', bg="#FFFFFF", font=("Calibri", 18))
name_label1.place(relx=0.878, rely=0.90, anchor='se')

name_label2 = tk.Label(root, text="Manya Chudasama", fg='#052A47', bg="#FFFFFF", font=("Calibri", 18))
name_label2.place(relx=0.95, rely=0.95, anchor='se')

root.mainloop()