import pyttsx3
engine = pyttsx3.init()

def speak(text):
    engine.setProperty('rate', 150)  
    engine.setProperty('volume', 1)  

    engine.say(text)  
    engine.runAndWait() 

if __name__ == "__main__":
    text_to_speak = input("Enter the text to be converted to speech: ")
    print("Here is the audio of the text that you have written")
    speak(text_to_speak)

