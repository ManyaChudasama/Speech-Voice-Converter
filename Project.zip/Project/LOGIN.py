import customtkinter as ctk
from tkinter import messagebox
import subprocess
from datetime import datetime
from PIL import Image, ImageTk 

ctk.set_appearance_mode("white") 
ctk.set_default_color_theme("green")

def track_login(username):
    with open("login_history.txt", "a") as file:
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        file.write(f"{username} logged in at {timestamp}\n")

def count_logins(username):
    with open("login_history.txt", "r") as file:
        logins = file.readlines()
    user_logins = [login for login in logins if login.startswith(username)]
    return len(user_logins)

def validate_login():
    username = entry_username.get()
    password = entry_password.get()

    correct_username = "User"
    correct_password = "PASS"
    admin_username = "Admin"
    admin_password = "main"

    if username == correct_username and password == correct_password:
        messagebox.showinfo("Login Successful", "Please click OK to open final page")
        root.destroy()
        subprocess.Popen(["python", "gui.py"])

        track_login(username)  

    elif username == admin_username and password == admin_password:
        messagebox.showinfo("Admin Logged in Successfully", "Please click OK to open final page")
        root.destroy()
        subprocess.Popen(["python", "admin_gui.py"])

        track_login(username) 

    else:
        messagebox.showerror("Login Failed", "Incorrect username or password.")

root = ctk.CTk()
root.title("Login Window")
root.geometry("1920x1080")

bg_image = Image.open("page.png")  
bg_image = bg_image.resize((1920, 1080))  
bg_photo = ImageTk.PhotoImage(bg_image)

canvas = ctk.CTkCanvas(root, width=700, height=500)
canvas.pack(fill="both", expand=True)

canvas.create_image(0, 0, anchor="nw", image=bg_photo)

frame = ctk.CTkFrame(canvas, width=900, height=700, corner_radius=10, fg_color="white", bg_color="white")
frame.place(relx=0.76, rely=0.9, anchor="se")

label_username = ctk.CTkLabel(frame, text="Username:", font=("Helvetica Neue", 16))
label_username.pack(pady=10)

entry_username = ctk.CTkEntry(frame, placeholder_text="Enter username", font=("Helvetica Neue", 16))
entry_username.pack(pady=10)

label_password = ctk.CTkLabel(frame, text="Password:", font=("Helvetica Neue", 16))
label_password.pack(pady=10)

entry_password = ctk.CTkEntry(frame, show="*", placeholder_text="Enter password", font=("Helvetica Neue", 16))
entry_password.pack(pady=10)

button_login = ctk.CTkButton(frame, text="Login", font=("Helvetica Neue", 16), command=validate_login)
button_login.pack(pady=20)

checkbox = ctk.CTkCheckBox(frame, text='Remember Me') 
checkbox.pack(pady=12, padx=10)

root.mainloop()