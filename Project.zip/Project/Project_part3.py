import pyttsx3
engine = pyttsx3.init()

def speak(text):
    engine.setProperty('rate', 150)  
    engine.setProperty('volume', 1)  

    engine.say(text)  
    engine.runAndWait()  

def read_file(file_path):
    with open(file_path, 'r') as file:
        text = file.read()
    return text

if __name__ == "__main__":
    file_path = 'Input.txt'  
    text_to_speak = read_file(file_path)
    print("Here is the audio of the text in the file")
    speak(text_to_speak)