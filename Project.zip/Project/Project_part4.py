import PyPDF2 
import pyttsx3 

file = open('file.pdf', 'rb') 
pdfReader = PyPDF2.PdfReader(file) 

from_page = pdfReader.pages[0] 
text = from_page.extract_text() 

print("Here is the audio of the text in the file")
speak = pyttsx3.init() 
speak.say(text) 
speak.runAndWait()
file.close()